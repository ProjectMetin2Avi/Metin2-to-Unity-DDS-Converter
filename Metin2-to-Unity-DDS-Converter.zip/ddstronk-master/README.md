# ddstronk
DDS-to-PNG converter

just a little qnd tool that converts DDS to PNG with [Pfim](https://github.com/nickbabcock/Pfim)
